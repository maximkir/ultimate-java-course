package com.trainologic.exercises.ultimatejava.chatclient;

import java.io.BufferedReader;
import java.io.Console;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.Socket;
import java.util.Properties;

import javax.swing.JFrame;

public class ChatClient {
	private final Socket socket;
	private ChatPanel chat;

	public ChatClient(String host, int port) throws IOException {
		socket = new Socket(host, port);
		chat = new ChatPanel(new OutputStreamWriter(socket.getOutputStream()));
		JFrame frm = new JFrame("Chat");
		frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frm.add(chat);
		frm.pack();
		frm.setVisible(true);
		new Thread(new Receiver()).start();

	}

	private class Receiver implements Runnable {
		@Override
		public void run() {
			try {
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(socket.getInputStream()));
				while (true) {
					String str = reader.readLine();
					chat.addText(str + "\n");
				}
			} catch (Exception e) {
				try {
					socket.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				e.printStackTrace();
			}
		}

	}

	public static void main(String[] args) throws Exception {
		Properties props = new Properties();
		props.load(new FileReader("conf.properties"));
		String host = props.getProperty("host");
		int port = Integer.parseInt(props.getProperty("port"));
		ChatClient chatClient = null;
		chatClient = new ChatClient(host, port);
		System.out.println(chatClient);

	}

	private void stop() throws IOException {
		socket.close();
	}

	public void startClient() throws IOException {
		Writer writer = new OutputStreamWriter(socket.getOutputStream());
		Console console = System.console();
		while (true) {
			String str = console.readLine();
			writer.write(str);
		}
	}

	@Override
	public String toString() {
		return String.format("ChatClient listening on %s port %d", socket
				.getInetAddress().getHostName(), socket.getPort());
	}

}
