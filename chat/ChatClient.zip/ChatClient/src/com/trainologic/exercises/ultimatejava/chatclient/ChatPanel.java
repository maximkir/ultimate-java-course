package com.trainologic.exercises.ultimatejava.chatclient;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.io.Writer;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class ChatPanel extends JPanel {

	private JTextArea history;
	private JTextField msg;
	private final Writer writer;

	public ChatPanel(Writer writer) {
		super(new BorderLayout());
		this.writer = writer;
		buildPanel();
	}

	private void buildPanel() {
		history = new JTextArea(30, 30);
		history.setEditable(false);
		history.setBackground(Color.LIGHT_GRAY);
		add(new JScrollPane(history), BorderLayout.CENTER);

		JPanel writingPanel = new JPanel();

		SendAction action = new SendAction();
		JButton send = new JButton(action);
		msg = new JTextField(30);
		msg.setAction(action);
		writingPanel.add(msg);
		writingPanel.add(send);
		add(writingPanel, BorderLayout.SOUTH);
	}

	/**
	 * Call this method to add text to the history area.
	 * 
	 * @param msg
	 */
	public void addText(final String msg) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				history.append(msg);
			}
		});
	}

	class SendAction extends AbstractAction {

		SendAction() {
			super("Send");
		}

		public void actionPerformed(ActionEvent e) {
			try {
				writer.write(msg.getText() + "\n");
				writer.flush();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			msg.setText("");
		}
	}

}
