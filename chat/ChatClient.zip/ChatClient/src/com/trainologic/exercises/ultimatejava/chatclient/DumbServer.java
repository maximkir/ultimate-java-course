package com.trainologic.exercises.ultimatejava.chatclient;

import java.io.FileReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;

public class DumbServer {
	public static void main(String[] args) throws Exception {
		Properties props = new Properties();
		props.load(new FileReader("conf.properties"));
		String host = props.getProperty("host");
		int port = Integer.parseInt(props.getProperty("port"));
		ServerSocket serverSocket = new ServerSocket(port);
		Socket socket = serverSocket.accept();
		Thread.sleep(343333);
	}
}
