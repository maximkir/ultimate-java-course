package com.bom.fp;

import fj.Equal;
import fj.F;
import fj.data.List;
import fj.data.Option;

public enum Position {
	C('S', 2), E('D', 3), N('W', 5), NE('E', 7), NW('Q', 11), S('X', 13), SE('C',
			17), SW('Z', 19), W('A', 23);

	private final char c;
	private final int i;

	private Position(char c, int i) {
		this.c = c;
		this.i = i;
	}

	public char toChar() {
		return c;
	}
	public int toInt() {
		return i;
	}
	public static Option<Position> fromChar(char c) {
		return Position.positions().find(toChar.andThen(Equal.charEqual.eq(c)));
	}
	
	public static List<Position> positions() {
		return List.list(values());
	}
	public static F<Position, Character> toChar = new F<Position, Character>() {

		@Override
		public Character f(Position pos) {
			return pos.toChar();
		}
	};
}
