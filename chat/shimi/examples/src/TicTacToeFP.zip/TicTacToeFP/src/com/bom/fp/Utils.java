package com.bom.fp;

import fj.data.Natural;
import fj.data.Stream;

public final class Utils {
	private Utils(){}
	
//	Stream<Natural> naturals = Stream.cons(Natural.ONE, Stream.f)
	
	
}
