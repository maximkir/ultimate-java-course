package com.bom.fp;

import com.bom.fp.Board.FinishedBoard;

import fj.F;
import fj.Function;
import fj.P;
import fj.P1;
import fj.data.Option;

public abstract class MoveResult {

	public abstract <X> X fold(P1<X> positionAlreadyOccupied,
			F<Board, X> keepPlaying, F<Board.FinishedBoard, X> gameOver);

	public static MoveResult gameOver(final FinishedBoard board) {
		return new MoveResult() {

			@Override
			public <X> X fold(P1<X> positionAlreadyOccupied,
					F<Board, X> keepPlaying, F<FinishedBoard, X> gameOver) {
				return gameOver.f(board);
			}
		};
	}

	public static MoveResult keepPlaying(final Board b) {
		return new MoveResult() {

			@Override
			public <X> X fold(P1<X> positionAlreadyOccupied,
					F<Board, X> keepPlaying, F<FinishedBoard, X> gameOver) {
				return keepPlaying.f(b);
			}
		};
	}

	public static MoveResult positionAlreadyOccupied() {
		return new MoveResult() {

			@Override
			public <X> X fold(P1<X> positionAlreadyOccupied,
					F<Board, X> keepPlaying, F<FinishedBoard, X> gameOver) {
				return positionAlreadyOccupied._1();
			}
		};
	}

	public Option<Board> keepPlaying() {
		return fold(P.p(Option.<Board> none()), Option.<Board> some_(),
				Function.<FinishedBoard, Option<Board>> constant(Option
						.<Board> none()));
	}
	
	public <A> A keepPlayingOr(P1<A> els, F<Board,A> board) {
		return keepPlaying().map(board).orSome(els._1());
	}
	public MoveResult tryMove(final Position p) {
		return fold(P.p(this), new F<Board, MoveResult>() {

			@Override
			public MoveResult f(Board a) {
				return a.moveTo(p);
			}
		}, Function.<FinishedBoard, MoveResult> constant(this));
	}
}
