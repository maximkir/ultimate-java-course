package com.bom.fp;

import fj.data.Option;

public enum GameResult {
	Draw, Player1Wins(Player.Player1), Player2Wins(Player.Player2);

	private final Option<Player> who;

	private GameResult() {
		this(Option.<Player> none());
	}

	private GameResult(Player player) {
		this(Option.fromNull(player));
	}

	private GameResult(Option<Player> player) {
		who = player;
	}

	public boolean isDraw() {
		return this == Draw;
	}

	public boolean isWin() {
		return !isDraw();
	}

	public static GameResult win(Player pl) {
		return pl == Player.Player1 ? Player1Wins : Player2Wins;
	}

	public Option<Player> winner() {
		return who;
	}

	public <X> X strictFold(X player1Wins, X player2Wins, X draw) {
		switch (this) {
		case Player1Wins:
			return player1Wins;
		case Player2Wins:
			return player2Wins;
		case Draw:
			return draw;
		default:
			throw new AssertionError("Impossible state");
		}
	}

}
