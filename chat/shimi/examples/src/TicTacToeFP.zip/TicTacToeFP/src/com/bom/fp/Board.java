package com.bom.fp;

import fj.Equal;
import fj.F;
import fj.F2;
import fj.Function;
import fj.P;
import fj.P2;
import fj.data.List;
import fj.data.Option;

public final class Board extends BoardLike {

	private static final List<Integer> winningNumbers = List.list(2 * 3 * 23,
			5 * 7 * 11, 13 * 17 * 19, 5 * 13 * 2, 7 * 17 * 3, 19 * 23 * 11,
			11 * 2 * 17, 7 * 2 * 19);

	private static final <A> F<A, F<A, Boolean>> alTRUE() {
		F<A, Boolean> inner = Function.<A, Boolean> constant(true);
		return Function.<A, F<A, Boolean>> constant(inner);
	}

	private final List<P2<Position, Player>> positions;

	private static F<List<P2<Position, Player>>, Boolean> isDraw = new F<List<P2<Position, Player>>, Boolean>() {

		@Override
		public Boolean f(List<P2<Position, Player>> positions) {
			return positions.length() == Position.values().length;
		}
	};
	private static F<List<Position>, Boolean> isWin = new F<List<Position>, Boolean>() {

		@Override
		public Boolean f(List<Position> positions) {
			return winningNumbers.exists(Equal.intEqual.eq(positions.foldLeft(
					new F2<Integer, Position, Integer>() {

						@Override
						public Integer f(Integer arg0, Position arg1) {
							return arg0 * arg1.toInt();
						}
					}, 1)));
		}
	};
	private static F<List<P2<Position, Player>>, Option<GameResult>> getGameResult = new F<List<P2<Position, Player>>, Option<GameResult>>() {

		@Override
		public Option<GameResult> f(List<P2<Position, Player>> moves) {

			List<List<P2<Player, Position>>> groupByPlayer = moves.map(
					P2.<Position, Player> swap_()).group(
					Equal.<Player, Position> p2Equal(Equal.<Player> anyEqual(),
							Equal.<Position> equal(Board.<Position> alTRUE())));

			List<P2<Player, List<Position>>> playersAndPositions = groupByPlayer
					.<P2<Player, List<Position>>> map(new F<List<P2<Player, Position>>, P2<Player, List<Position>>>() {

						@Override
						public P2<Player, List<Position>> f(
								List<P2<Player, Position>> a) {

							return P.p(a.head()._1(),
									a.map(P2.<Player, Position> __2()));
						}
					});

			Option<Player> player = playersAndPositions.find(
					P2.<Player, List<Position>> __2().andThen(isWin)).map(
					P2.<Player, List<Position>> __1());

			Option<GameResult> result = player.map(new F<Player, GameResult>() {

				@Override
				public GameResult f(Player a) {
					return GameResult.win(a);
				}
			});

			return result.orElse(isDraw.f(moves) ? Option.some(GameResult.Draw)
					: Option.<GameResult> none());
		}
	};

	public static final class FinishedBoard extends BoardLike {
		private final List<P2<Position, Player>> oPositions;
		private final GameResult gr;

		private FinishedBoard(GameResult gr,
				List<P2<Position, Player>> occPositions) {
			this.oPositions = occPositions;
			this.gr = gr;
		}

		@Override
		public boolean isEmpty() {
			return oPositions.isEmpty();
		}

		@Override
		public List<Position> occupiedPositions() {
			return oPositions.map(P2.<Position, Player> __1());
		}

		@Override
		public int nmoves() {
			return this.oPositions.length();
		}

		@Override
		public Option<Player> playerAt(final Position p) {
			Option<P2<Position, Player>> foundPos = oPositions
					.find(new F<P2<Position, Player>, Boolean>() {

						@Override
						public Boolean f(P2<Position, Player> arg0) {
							return arg0._1() == p;
						}
					});
			return foundPos.map(P2.<Position, Player> __2());
		}

		@Override
		public Player whoseTurn() {
			return oPositions.length() % 2 == 0 ? Player.Player1
					: Player.Player2;
		}

		public Board takeBack() {
			return new Board(oPositions.tail());
		}

		public GameResult result() {
			return gr;
		}

	}

	public static final class EmptyBoard extends BoardLike {
		private static EmptyBoard instance = new EmptyBoard();

		private EmptyBoard() {
		};

		public static EmptyBoard empty() {
			return instance;
		}

		@Override
		public boolean isEmpty() {
			return true;
		}

		@Override
		public List<Position> occupiedPositions() {
			return List.nil();
		}

		@Override
		public int nmoves() {
			return 0;
		}

		@Override
		public Option<Player> playerAt(Position p) {
			return Option.none();
		}

		@Override
		public Player whoseTurn() {
			return Player.Player1;
		}

		public Board moveTo(Position pos) {
			return new Board(List.single(P.p(pos, whoseTurn())));
		}

	}

	private Board(List<P2<Position, Player>> occPositions) {
		this.positions = occPositions;
	}

	public boolean isEmpty() {
		return positions.isEmpty();
	}

	public List<Position> occupiedPositions() {
		return positions.map(P2.<Position, Player> __1());
	}

	public int nmoves() {
		return positions.length();
	}

	public Option<Player> playerAt(final Position p) {
		F<Position, Boolean> eqP = Equal.<Position> anyEqual().eq(p);
		Option<P2<Position, Player>> foundPos = positions.find(eqP
				.<Player> mapFst().andThen(P2.<Boolean, Player> __1()));
		return foundPos.map(P2.<Position, Player> __2());
	}

	public Player whoseTurn() {
		return positions.length() % 2 == 0 ? Player.Player1 : Player.Player2;
	}

	public TakenBack takeBack() {
		List<P2<Position, Player>> tail = positions.tail();
		return tail.isEmpty() ? TakenBack.isEmpty() : TakenBack
				.isBoard(new Board(tail));
	}

	public MoveResult moveTo(final Position p) {
		return isOccupied(p) ? MoveResult.positionAlreadyOccupied()
				: getGameResult
						.f(positions.cons(P.p(p, whoseTurn())))
						.map(new F<GameResult, MoveResult>() {
							@Override
							public MoveResult f(GameResult gr) {
								return MoveResult.gameOver(new FinishedBoard(
										gr, positions.cons(P.p(p, whoseTurn()))));
							}
						})
						.orSome(MoveResult.keepPlaying(new Board(positions
								.cons(P.p(p, whoseTurn())))));
	}

}
