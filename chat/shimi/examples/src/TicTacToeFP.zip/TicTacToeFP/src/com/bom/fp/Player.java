package com.bom.fp;

import fj.F;

public enum Player {
	Player1('X'), Player2('O');

	private final char symbol;

	private Player(char symbol) {
		this.symbol = symbol;
	}

	public char toSymbol() {
		return symbol;
	}

	public Player alternate() {
		return this == Player1 ? Player2 : Player1;
	}

	public static F<Player, Character> toSymbol = new F<Player, Character>() {
		@Override
		public Character f(Player pl) {
			return pl.toSymbol();
		}
	};

}
