package com.bom.fp;

import com.bom.fp.Board.EmptyBoard;
import com.bom.fp.Board.FinishedBoard;

import fj.F;
import fj.P;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		
		EmptyBoard sg = Board.EmptyBoard.empty();
	
		
		
		
		
	}

	
}
