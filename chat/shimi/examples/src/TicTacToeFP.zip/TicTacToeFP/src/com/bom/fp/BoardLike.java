package com.bom.fp;

import fj.Equal;
import fj.P1;
import fj.data.List;
import fj.data.Option;

public abstract class BoardLike {
	public abstract boolean isEmpty();

	public abstract List<Position> occupiedPositions();

	public boolean isOccupied(Position p) {
		return occupiedPositions().exists(Equal.<Position> anyEqual().eq(p));
	}
	public boolean isNotOccupied(Position p) {
		return !isOccupied(p);
	}
	public abstract int nmoves();
	
	public abstract Option<Player> playerAt(Position p);
	
	public Player playerAtOr(Position p, P1<Player> or) {
		return playerAt(p).orSome(or);
	}
	public abstract Player whoseTurn();
	public Player whoseNotTurn() {
		return whoseTurn().alternate();
	}
	
}
