package com.trainologic.multithreading.tasks;



/**
 * This is a general interface that represent a task.
 * @author galmarder
 *
 */
public interface Task {
	
	void execute();

}
