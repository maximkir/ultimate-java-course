package com.trainologic.multithreading.tasks;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;


public class OrderFlow {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Executor executor = Executors.newFixedThreadPool(10);
		
		Task logOrder = new AsyncTaskCollection(executor, new DemoTask("Log Order"));
		
		Task checkInventory = new DemoTask("Check Inventory");
		
		Task sendInvoice = new DemoTask("Send Invoice");
		Task orderShipment = new DemoTask("Order Shipment");
		Task taskFork = new TaskFork(executor, sendInvoice, orderShipment);
		
		Task sendApproval = new DemoTask("Send Approval");
		
		Task sequence = new TaskSequence(logOrder, checkInventory, taskFork, sendApproval);
		
		sequence.execute();

	}

}
