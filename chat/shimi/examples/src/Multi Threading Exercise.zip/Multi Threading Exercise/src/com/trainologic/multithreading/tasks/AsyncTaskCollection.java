package com.trainologic.multithreading.tasks;

import java.util.List;
import java.util.concurrent.Executor;

/**
 * A TaskCollection that executes the tasks concurrently using the given executor.
 * This TaskCollection does not wait for the tasks to be completed.
 * @author galmarder
 *
 */
public class AsyncTaskCollection extends TaskCollection {

	private Executor threadPool;
	
	public AsyncTaskCollection(Executor threadPool, Task...tasks) {
		super(tasks);
		this.threadPool = threadPool;
	}
	
	public void execute() {
		for (Task currTask : tasks) {
			threadPool.execute(new TaskRunner(currTask));
		}
	}
	
	
	private static class TaskRunner implements Runnable {
		
		private Task task;

		TaskRunner(Task task) {
			this.task = task;
		}
		public void run() {
			task.execute();
		}
		
	}

}
