package com.trainologic.multithreading.tasks;

public class DemoTask implements Task {
	
	private String msg;
	private long sleep;
	
	

	public DemoTask(String msg) {
		this(msg, 1000);
	}
	
	public DemoTask(String msg, long sleep) {
		super();
		this.msg = msg;
		this.sleep = sleep;
	}



	public void execute() {
		System.out.println("started: " + msg);
		try {
			Thread.sleep(sleep);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("ended: " + msg);

	}

}
