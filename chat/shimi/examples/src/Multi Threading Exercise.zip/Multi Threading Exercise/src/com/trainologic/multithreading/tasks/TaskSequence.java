package com.trainologic.multithreading.tasks;

import java.util.List;



/**
 * A TaskCollection that executes the nested tasks on one thread at the order of their appearance in the Task list.
 * @author galmarder
 *
 */
public class TaskSequence extends TaskCollection {
	
	public TaskSequence(Task...tasks) {
		super(tasks);
	}

	
	public void execute() {
		
		
		for(Task task : tasks) {
			task.execute();
		}
		
	}
	
	
	

}
