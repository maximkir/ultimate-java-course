package com.trainologic.multithreading.tasks;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;


/**
 * A TaskCollection that uses an Executor to execute all tasks concurrently.
 * The TaskFork waits for all nested tasks to complete before its execute method returns.
 * @author galmarder
 *
 */
public class TaskFork extends TaskCollection {
	
	private Executor threadPool;

	public TaskFork(Executor threadPool, Task...tasks) {
		super(tasks);
		this.threadPool = threadPool;
	}

	
	public void execute() {
		CountDownLatch latch = new CountDownLatch(tasks.size());
		try {
			for (Task task : tasks) {
				threadPool.execute(new LatchNotifyer(task, latch));
			}
			
			//This method blocks until all threads finish executing all tasks.
			latch.await();
		} catch (InterruptedException e) {
			// TODO rethrow the relevant exception
			e.printStackTrace();
		}
		
	}
	
	// This is a Task wrapper that adapts the task to the Executor API and also notifies the CountDownLatch that a sub task is finished.
	private class LatchNotifyer implements Runnable {
		
		private Task task;
		private CountDownLatch latch;
		
		private LatchNotifyer(Task task, CountDownLatch latch) {
			this.task = task;
			this.latch = latch;
		}

		
		public void run() {
			task.execute();
			latch.countDown();
		}
		
	}

}


