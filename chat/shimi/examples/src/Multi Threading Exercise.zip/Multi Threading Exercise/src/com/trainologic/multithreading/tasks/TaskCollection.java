package com.trainologic.multithreading.tasks;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

/**
 * Task collection is an aggregation of Tasks to perform.
 * This class follows the composite design pattern, thus a TaskCollection is also a Task.
 * This pattern enables the nesting of TaskCollections.
 * @author galmarder
 *
 */

public abstract class TaskCollection implements Task {
	
	protected Collection<Task> tasks;
	
	
	protected TaskCollection(Task...tasks) {
		this.tasks = Arrays.asList(tasks);
	}

}
