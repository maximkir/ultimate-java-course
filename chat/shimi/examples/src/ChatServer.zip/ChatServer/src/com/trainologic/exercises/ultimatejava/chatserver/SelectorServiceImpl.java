package com.trainologic.exercises.ultimatejava.chatserver;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

public class SelectorServiceImpl implements SelectorService {

	private final Selector selector;
	private final Object guard = new Object();
	private final ChatServer server;

	public SelectorServiceImpl(ChatServer chatServer) throws IOException {
		selector = Selector.open();
		this.server = chatServer;
	}

	@Override
	public void addSocketChannel(SocketChannel channel) throws IOException {
		channel.configureBlocking(false);
		// Register the channel to the selector // need to use GUARD
		synchronized (guard) {
			selector.wakeup();
			channel.register(selector, SelectionKey.OP_READ);
		}

	}

	@Override
	public void sendMsgToAllClients(String msg) {
		// TODO Auto-generated method stub

	}

	@Override
	public void run() {
		try {
			ByteBuffer readBuffer = ByteBuffer.allocate(1000000);
			while (true) {
				synchronized (guard) {
				}

				if (selector.select() == 0) {
					continue;
				}
				Set<SelectionKey> selectedKeys = selector.selectedKeys();
				for (Iterator<SelectionKey> iter = selectedKeys.iterator(); iter
						.hasNext();) {
					SelectionKey key = iter.next();

					// if isWritable
					// remove the write op
					// get the attachment
					// perform the write
					// if more, register for write again

					System.out.println(selectedKeys.size());

					if (key.isReadable()) {
						System.out.println("READABLE");
						// iter.remove();
						SocketChannel channel = (SocketChannel) key.channel();
						channel.read(readBuffer);
						readBuffer.flip();
						byte[] arr = new byte[readBuffer.limit()];
						readBuffer.get(arr);
						String str = new String(arr);
						readBuffer.limit(readBuffer.capacity());
						readBuffer.rewind();
						System.out.println("received: " + str);
						server.sendToWrite(str);
					}

				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
