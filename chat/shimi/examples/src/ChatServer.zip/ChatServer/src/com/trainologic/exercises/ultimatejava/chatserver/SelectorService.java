package com.trainologic.exercises.ultimatejava.chatserver;

import java.io.IOException;
import java.nio.channels.SocketChannel;

public interface SelectorService extends Runnable {
	void sendMsgToAllClients(String msg);

	void addSocketChannel(SocketChannel channel) throws IOException;
}
