package com.trainologic.exercises.ultimatejava.chatserver;

import java.io.FileReader;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;

public class ChatServer {
	private volatile boolean running = true;
	private ServerSocketChannel serverSocketChannel;
	private Set<SocketChannel> socketChannels = new CopyOnWriteArraySet<SocketChannel>();

	private SelectorService selectorService;

	public ChatServer(int port) throws IOException {
		serverSocketChannel = ServerSocketChannel.open();
		serverSocketChannel.socket().bind(new InetSocketAddress(port));
		selectorService = new SelectorServiceImpl(this);
	}

	public void start() throws IOException {
		new Thread(selectorService).start();
		while (running) {
			SocketChannel socketChannel = serverSocketChannel.accept();
			System.out.println("Client connected");
			socketChannels.add(socketChannel);
			selectorService.addSocketChannel(socketChannel);
		}
	}

	public void stop() {
		running = false;
		try {
			serverSocketChannel.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		for (SocketChannel socketChannel : socketChannels) {
			try {
				socketChannel.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) throws Exception {
		Properties props = new Properties();
		props.load(new FileReader("conf.properties"));
		int port = Integer.parseInt(props.getProperty("port"));
		ChatServer chatServer = new ChatServer(port);
		chatServer.start();
	}

	public void sendToWrite(String str) throws IOException {
		ByteBuffer buffer = ByteBuffer.allocate(10000);
		buffer.put(str.getBytes());
		buffer.flip();
		for (SocketChannel channel : socketChannels) {
			channel.write(buffer);
			buffer.rewind();
		}
	}
}
